# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
num1 = int(input("Insira um numero: "))
num2 = int(input("Insira outro numero: "))
print("A soma de {} e {} é {}".format(num1,num2,num1+num2))


