# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
n = int(input("insira um numero: "))
print ('Você escolheu o numero {}, seu antecessor é {} e seu sucessor {}!'.format(n,n-1,n+1))
