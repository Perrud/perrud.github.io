# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
print (' ---Conversor de moedas--- ')
m = float(input('Quanto voce tem: R$'))
n = float(input('Valor da moeda estrangeira: $'))
r = m/n
print('Com R${} voce compra ${:.2f}'.format(m,r))