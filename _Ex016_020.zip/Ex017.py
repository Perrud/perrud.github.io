# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
from math import hypot
x = float(input('Cateto adjacente: '))
y = float(input('Cateto oposto: '))
print(hypot(x,y))
