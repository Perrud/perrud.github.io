# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
palavra = input("Palavra ou frase: ")
print("O tipo é {} ".format(type(palavra)))
print("É numero ?", palavra.isnumeric())
print("É alfabetico? ", palavra.isalpha())
print("É alfanumerico? ", palavra.isalnum())
print("É em letras maiusculas? ", palavra.isupper())
print("É em letras minusculas? ", palavra.islower())
print("Fim")
