# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
x = float(input('Altura da parede: '))
y = float(input('Largura da parede: '))
Area = x*y
tinta = Area / 2
print("""
Altura da parede {:.1f}m e largura {:.1f}
Area total = {:.1f}m²
Tinta necessaria: {:.1f}L
""".format(x,y,Area,tinta))
