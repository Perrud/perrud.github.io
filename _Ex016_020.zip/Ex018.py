# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
from math import sin,cos,tan, radians
a = int(input('Angulo: '))
s = sin(radians(a))
c = cos(radians(a))
t = tan(radians(a))
print("""
Angulo escolhido {}
O sen para esse angulo é: {:.2f}
O cos para esse angulo é: {:.2f}
A tan para esse angulo é: {:.2f}
""".format(a,s,c,t))
