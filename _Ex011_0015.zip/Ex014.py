# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
def op():
    opp = input('Voce quer converter a partir de "c", "k" ou "f"? ')
    if opp == 'c':
        c = float(input('Temperatura em celsius: '))
        ct(c)
    elif opp == 'k':
        k = float(input('Temperatura em kelvins: '))
        kt(k)
    elif opp == 'f':
        f = float(input('Temperatura em fahrenheit: '))
        ft(f)
    else:
        print ('\n digite corretamente, apenas uma letra sem espaços!! \n')
        op()
def ct(x):
    rf = 1.8*x + 32
    rk = x + 273
    print("""
    --->Conversao feita<---
    Temperatura em C: {:.1f}
    Temperatura em F: {:.1f}
    Temperatura em K: {:.1f}
    """.format(x,rf,rk))
    op()
def kt(x):
    rf = x - 273
    rk = ((((x-273)/5)*9)+32)
    print("""
    --->Conversao feita<---
    Temperatura em K: {:.1f}
    Temperatura em C: {:.1f}
    Temperatura em F: {:.1f}
    """.format(x,rf,rk))
    op()
def ft(x):
    rf = (x-32) / 1.8
    rk = ((((x-32)/9)*5)+273)
    print("""
    --->Conversao feita<---
    Temperatura em F: {:.1f}
    Temperatura em C: {:.1f}
    Temperatura em K: {:.1f}
    """.format(x,rf,rk))
    op()
op()
