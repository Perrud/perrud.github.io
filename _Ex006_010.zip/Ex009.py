# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
n = int(input('Insira um numero: '))
print(""" ---------- Tabuada --------
{} x 1 = {}
{} x 2 = {}
{} x 3 = {}
{} x 4 = {}
{} x 5 = {}
{} x 6 = {}
{} x 7 = {}
{} x 8 = {}
{} x 9 = {}
""".format(n, n, n, n*2, n, n*3, n, n*4, n, n*5, n, n*6, n, n*7, n, n*8, n, n*9))
