# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
n = int(input('Valor original'))
print ("""
valor e^-3 = {}
valor e^-2 = {}
valor e^-1 = {}
valor e^+1 = {}
valor e^+1 = {}
valor e^+2 = {}
valor e^+3 = {}
""".format(n/1000,n/100,n/10,n,float(n*10),float(n*100),float(n*1000)))