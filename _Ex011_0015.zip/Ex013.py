# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
salario = float(input('Salario inicial: R$'))
aumento = float(input('Aumento: %'))
final = (salario+(salario*(aumento/100)))
print("""
Salario original: R${:.2f}
Aumento: {:.0f}%
Salario final R${:.2f}
""".format(salario,aumento,final))
