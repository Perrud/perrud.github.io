# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
nome = input("Insira seu nome: ")
print("Ola {}".format(nome))
