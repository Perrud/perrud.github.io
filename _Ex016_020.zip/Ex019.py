# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
from random import choice
a = ['cachorro','gato','papagaio','tartaruga']
print('Escolhido: {}'.format(choice(a)))
