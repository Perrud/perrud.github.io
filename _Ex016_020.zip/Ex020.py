# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
import random
a = ['cachorro','gato','papagaio','tartaruga']
print(a)
b = len(a)
while b > 0:
    w = int(random.triangular(0,b))
    print(a[w])
    del a[w]
    b = b - 1
if b == 0:
    print('Fim')