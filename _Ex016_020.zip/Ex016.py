# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
from math import trunc,pi
n = float(input('Numero: '))
print (trunc(n))
