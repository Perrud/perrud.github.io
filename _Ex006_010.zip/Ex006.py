# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
n = int(input('Insira um numero: '))
print('Numero escolhido {}'.format(n))
print('Dobro: {} e Triplo: {}'.format(n*2, n*3))
print('Raiz quadrada: {} '.format(n**(1/2)))
print('fim')
