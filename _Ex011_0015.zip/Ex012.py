# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
preco = float(input('Valor original:R$'))
desconto = float(input('Valor do desconto: %'))
total = preco - (preco*(desconto/100))
print("""
Valor original: R${:.2f}
Valor do desconto: {}%
Total: {:.2f}
""".format(preco,desconto,total))