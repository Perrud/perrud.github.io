# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
n = int(input('Insira um numero: '))
m = int(input('Insira outro numero: '))
c = ((n+m)/2)
print('A média é {}'.format(c))
print('Fim')
