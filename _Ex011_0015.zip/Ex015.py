# Ex from http://www.cursoemvideo.com/course/curso-python-3/
# directly on ytb https://goo.gl/KRNS9c
dias = int(input('Dias: '))
km = float(input('Km rodados: '))
r = (dias*60)+(km*0.15)
print('Total a pagar: R$ {:.2f}'.format(r))
